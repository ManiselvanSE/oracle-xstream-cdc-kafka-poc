#!/usr/bin/env bash
# Run HammerDB CLI with MTX_TRANSACTION_ITEMS custom driver (not TPCC).
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./hammerdb-oracle-env.sh
source "${SCRIPT_DIR}/hammerdb-oracle-env.sh"

: "${HDB_MTX_PASS:?Set HDB_MTX_PASS to ORDERMGMT password}"

export HDB_MTX_USER="${HDB_MTX_USER:-ordermgmt}"
export HDB_MTX_TNS="${HDB_MTX_TNS:-RAC_XSTRPDB_POC}"
export HDB_MTX_TOTAL_ITERATIONS="${HDB_MTX_TOTAL_ITERATIONS:-100000}"
export HDB_MTX_RAISEERROR="${HDB_MTX_RAISEERROR:-false}"

exec hammerdbcli tcl auto "${SCRIPT_DIR}/hammerdb-mtx-transaction-items-run.tcl"
