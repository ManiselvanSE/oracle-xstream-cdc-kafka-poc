# =============================================================================
# HammerDB CUSTOM DRIVER — ORDERMGMT.MTX_TRANSACTION_ITEMS (iteration mode)
# Loaded via: customscript in hammerdb-mtx-transaction-items-run.tcl
#
# TPROC-C only runs against the TPCC schema; this script replaces that workload
# with repeated INSERTs for CDC testing. Requires Oratcl + tpcccommon (HammerDB).
#
# Config: env vars HDB_MTX_USER, HDB_MTX_PASS, HDB_MTX_TNS, HDB_MTX_TOTAL_ITERATIONS,
#         optional HDB_MTX_RAISEERROR (true|false)
# =============================================================================

if { [catch {package require Oratcl} message] } {
  error "Failed to load Oratcl: $message"
}
if { [catch {package require tpcccommon} message] } {
  error "Failed to load tpcccommon: $message"
}
namespace import tpcccommon::*

if { ![info exists ::env(HDB_MTX_USER)] || $::env(HDB_MTX_USER) eq "" } {
  error "Set HDB_MTX_USER (e.g. ordermgmt)"
}
if { ![info exists ::env(HDB_MTX_PASS)] || $::env(HDB_MTX_PASS) eq "" } {
  error "Set HDB_MTX_PASS"
}
if { ![info exists ::env(HDB_MTX_TNS)] || $::env(HDB_MTX_TNS) eq "" } {
  error "Set HDB_MTX_TNS (TNS alias, e.g. RAC_XSTRPDB_POC)"
}
if { ![info exists ::env(HDB_MTX_TOTAL_ITERATIONS)] || $::env(HDB_MTX_TOTAL_ITERATIONS) eq "" } {
  set ::env(HDB_MTX_TOTAL_ITERATIONS) 100000
}

set connect "$::env(HDB_MTX_USER)/$::env(HDB_MTX_PASS)@$::env(HDB_MTX_TNS)"
set total_iterations [expr { int($::env(HDB_MTX_TOTAL_ITERATIONS)) }]
set RAISEERROR false
if { [info exists ::env(HDB_MTX_RAISEERROR)] && [string tolower $::env(HDB_MTX_RAISEERROR)] eq "true" } {
  set RAISEERROR true
}
set KEYANDTHINK false

proc OracleLogon { connectstring lda } {
  set lda [oralogon $connectstring ]
  SetNLS $lda
  oraautocom $lda on
  return $lda
}

proc SetNLS { lda } {
  set curn_nls [oraopen $lda ]
  set nls(1) "alter session set NLS_LANGUAGE = AMERICAN"
  set nls(2) "alter session set NLS_TERRITORY = AMERICA"
  for { set i 1 } { $i <= 2 } { incr i } {
    if { [ catch {orasql $curn_nls $nls($i)} message ] } {
      puts "$message $nls($i)"
    }
  }
  oraclose $curn_nls
}

# Prepared INSERT (NOT NULL columns only; PK = UNIQUE_SEQ_NUMBER)
set sql_ins {
INSERT INTO ORDERMGMT.MTX_TRANSACTION_ITEMS (
  TRANSFER_ID, PARTY_ID, USER_TYPE, ENTRY_TYPE, ACCOUNT_ID,
  TRANSFER_DATE, TRANSACTION_TYPE, SECOND_PARTY, PROVIDER_ID,
  TXN_SEQUENCE_NUMBER, PAYMENT_TYPE_ID, SECOND_PARTY_PROVIDER_ID, UNIQUE_SEQ_NUMBER,
  REQUESTED_VALUE, APPROVED_VALUE, TRANSFER_STATUS
) VALUES (
  :trf, :pty, 'REG', 'DR', :acc,
  SYSDATE, 'TRANS', :sec, 1,
  :txnseq, 1, 1, :seq,
  1000, 1000, 'COM'
)
}

set lda [ OracleLogon $connect lda ]
set curn [oraopen $lda ]
oraparse $curn $sql_ins

set vid 0
if { [llength [info commands thread::id]] } {
  catch { set vid [thread::id] }
}

puts "Processing $total_iterations MTX_TRANSACTION_ITEMS inserts (output suppressed)..."

for { set it 0 } { $it < $total_iterations } { incr it } {
  if { ![catch {tsv::get application abort} a] && $a } { break }

  set ts [ clock format [clock seconds] -format %Y%m%d%H%M%S ]
  set seq [string range "SEQ-MTX-[clock microseconds]-$vid-$it-[expr {int(rand()*1e6)}]" 0 49]
  set trf [string range "T$ts$it" 0 19]
  set pty "P001"
  set acc "ACC001"
  set sec "P002"
  set txnseq [expr {1000 + ($it % 999999000)}]

  orabind $curn :trf $trf :pty $pty :acc $acc :sec $sec :txnseq $txnseq :seq $seq
  if { [catch {oraexec $curn} message] } {
    if { $RAISEERROR } {
      error "MTX insert: $message [ oramsg $curn all ]"
    }
  }
}

oraclose $curn
oralogoff $lda
