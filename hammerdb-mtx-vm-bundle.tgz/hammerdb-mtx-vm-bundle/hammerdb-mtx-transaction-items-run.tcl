#!/bin/tclsh
# =============================================================================
# HammerDB CLI — MTX_TRANSACTION_ITEMS load (custom driver, not TPROC-C)
#
# TPROC-C targets TPCC.* only. For ORDERMGMT.MTX_TRANSACTION_ITEMS CDC load,
# use this script instead of hammerdb-tprocc-run-production.tcl.
#
#   source hammerdb-oracle-env.sh
#   export HDB_MTX_PASS='<ordermgmt_password>'
#   # optional: HDB_MTX_USER HDB_MTX_TNS HDB_MTX_TOTAL_ITERATIONS HDB_MTX_RAISEERROR
#   hammerdbcli tcl auto hammerdb-mtx-transaction-items-run.tcl 2>&1 | tee mtx-run.log
#
# Or: ./hammerdb-mtx-run-production.sh
#
# total_iterations is per virtual user (same semantics as TPROC-C test mode).
# =============================================================================

if { [info exists ::env(TMP)] } {
  set tmpdir $::env(TMP)
} else {
  set tmpdir /tmp
}

puts "=== HammerDB Oracle CUSTOM: MTX_TRANSACTION_ITEMS (iteration) ==="

foreach {key def} {
  HDB_MTX_USER ordermgmt
  HDB_MTX_TNS RAC_XSTRPDB_POC
  HDB_MTX_TOTAL_ITERATIONS 100000
  HDB_MTX_RAISEERROR false
} {
  if { ![info exists ::env($key)] || $::env($key) eq "" } {
    set ::env($key) $def
  }
}

if { ![info exists ::env(HDB_MTX_PASS)] || $::env(HDB_MTX_PASS) eq "" } {
  puts stderr "ERROR: export HDB_MTX_PASS (ORDERMGMT password)."
  exit 1
}

dbset db ora
dbset bm TPC-C

# Unused by custom driver but keeps dict consistent with other Oracle scripts
diset connection system_user SYSTEM
diset connection system_password {unused_by_mtx_driver}
diset connection instance $::env(HDB_MTX_TNS)

diset tpcc tpcc_user $::env(HDB_MTX_USER)
diset tpcc tpcc_pass $::env(HDB_MTX_PASS)
diset tpcc ora_driver test
diset tpcc total_iterations $::env(HDB_MTX_TOTAL_ITERATIONS)
diset tpcc keyandthink false
diset tpcc raiseerror false

set here [file dirname [file normalize [info script]]]
set mtxscript [file join $here hammerdb-mtx-custom-driver.tcl]
if { ![file exists $mtxscript] } {
  puts stderr "ERROR: Missing custom driver: $mtxscript"
  exit 1
}

customscript $mtxscript

puts "TEST STARTED"

vuset vu vcpu
vucreate
tcstart
tcstatus

set jobid [ vurun ]

vudestroy
tcstop
puts "TEST COMPLETE jobid=$jobid"

set of [ open $tmpdir/ora_mtx_tprocc w ]
puts $of $jobid
close $of
